import java.io.BufferedWriter;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.Collectors;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;


public class Assignment_1 {

	public static void main(String[] args) throws Exception {
	//Creates inverted index

		InvIndex invIndex = new InvIndex();
      	PreProcess preProcess = new PreProcess();
      	System.out.println("Processing Documents");
      	long startIndextime = System.nanoTime();
      	try{
         	//[reprocesses documents and loads into inverted index
         	invIndex = preProcess.makeIndex("/Users/johnambali/Desktop/Assignment 1/StopWords.txt","/Users/johnambali/Desktop/Assignment 1/Trec_microblog11.txt"); 
      	} 
      	catch (Exception e){
	         e.printStackTrace();
	         System.out.println("Error occured while building inverted index");
	         System.exit(1);
      	}
   
     	System.out.println("Inverted Index was built in "+(System.nanoTime() - startIndextime) / 1000000000 + " seconds.");
        
       //stores queries inside array lisr
     	List<Query> queries = new ArrayList<>();
       
      	try{
	         //initializes XML Parser
	         DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder builder = factory.newDocumentBuilder();
	         Document doc = builder.parse(new File("topics_MB1-49.txt"));
	         doc.getDocumentElement().normalize();
	         System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         NodeList nList = doc.getElementsByTagName("top");
	         System.out.println("----------------------------");
            
            
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	                  //add num tags and title tags into query and add to query list
	               queries.add(new Query(eElement.getElementsByTagName("num").item(0).getTextContent(), eElement.getElementsByTagName("title").item(0).getTextContent().trim() ));
	               System.out.println(queries.size());
	            }
	         }
            
      } catch(Exception e){
	    	 e.printStackTrace();
      }
        
      
      	final Map<String, Double> scores = new HashMap<>(); //scores data structure

      
     //Changed this to match the file location. Removed printWriter and used path and buffwriter 
     

     	File file = new File("/Users/johnambali/Desktop/Assignment 1/Results.txt");
     	PrintWriter printWriter = new PrintWriter (file);

      	//Path path = Paths.get("/Users/johnambali/Desktop/Assignment 1/Results.txt");
      	//BufferedWriter buffWriter = Files.newBufferedWriter(path);


      	for (Query query : queries) { //compares each query term to the document inverted index
	         
	         System.out.println("Running query: " + query.getId());
	         //buffWriter.println("Running query: " + query.getId());
	        
	        for (String term : query.getTerms()) {
	            Map<String, Double> tfidfMap = invIndex.calcTfIdf(term);
	            
	            InvIndex tmpIndex = invIndex;
	            tfidfMap.forEach(
	                  (docid, idfscore) -> {
	                     double score = (0.5 + 0.5 * query.getFrequency(term)) * tmpIndex.calcIdf(term) * idfscore; //calculate similarity score 
	                     if (scores.containsKey(term)) {
	                        scores.merge(term, score, Double::sum);
	                     
	                     } else {
	                        scores.put(docid, score);
	                     }
	                   
	                  });    
	                   
	        }
	         
	        Map<String, Double> sortedScores = scores.entrySet() //sorts scoreList and selects first 1000 entries. Then stores in a HashMap
	                       .stream()
	                       .sorted(Map.Entry.comparingByValue(Collections.reverseOrder()))
	                       .limit(1000)
	                       .collect(Collectors.toMap(
	                               Map.Entry::getKey,
	                               Map.Entry::getValue,
	                               (e1, e2) -> e1,
	                               LinkedHashMap::new
	                     ));
	                       
	                        
	            
	            
	        // Step 4. changes creates array and prints result in TREC format
	         
	        int [] id_arr = { 001 };  
			sortedScores.forEach((key, value) -> {
	        	try {
	              printWriter.println(query.getId() + "\tQ0\t" + key + "\t" + id_arr[0] + "\t" + new DecimalFormat("#.00").format(value) + "\tmyRun\n");
	       		  printWriter.flush();

	           } 
	           catch (Exception e) {
	              e.printStackTrace();
	           }
	            id_arr[0]++; 

	        });
	      	
	    }

	      	printWriter.close(); 
    	
 	}
}
 


