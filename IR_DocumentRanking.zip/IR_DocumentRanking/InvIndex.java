import java.util.HashMap;
import java.util.Map;

public class InvIndex {
    private Map<String, IndexedTerm> index = new HashMap<>();

    public void insertTerm( String docID, String terms){
        if (index.containsKey(terms)){
            index.get(terms).addDocID(docID);
        }
        else{
            index.put(terms, new IndexedTerm(docID));
        }
    }

    
    double idf(String terms){
        return Math.log(index.size() / index.get(terms).getDf());
    }


    Map<String, Double> calcTfIdf(final String terms){
        if (!index.containsKey(terms)){
            return new HashMap<>();
        }


        IndexedTerm indexedTerm = index.get(terms);
        Double idf = Math.log(index.size()/ indexedTerm.getDf());
        Map<String, Double> tfIdf = new HashMap<>();
        indexedTerm.getPostingsList().forEach (doc -> tfIdf.put(doc.getDocID(), idf*getTf()));
        return tfIdf;
    }





}