import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PreProcess {

    
    private List<String> readFile(final String fileLocation) throws IOException {
        Stream<String> stream = Files.lines(Paths.get(fileLocation));
        return stream.collect(Collectors.toList());
    }

    InvIndex makeIndex (String stopsFile,String documentsFile) throws IOException{
         
        list<String> StopWords = readFile(stopsFile);
        for (String DocwWithKey : readFile (documentsFile)){
             
            List<String> word = new ArrayList<>(Arrays.asList(DocwWithKey.toLowerCase().replaceAll("[^a-z]"," ").trim().split("\\s+")));

           
            word.removeAll(stopWords); 

        
            documents.add(new Document(DocwWithKey.substring(0, 17), word));
        }

        InvIndex index = new InvIndex();

        System.out.println(documents.size());

        
        for (Document document : documents){
            for (String words: document.getWord());
            index.insertTerm(document.getID(), word);

        }

        return index;
    }





}