public class DocumentFreq {
    private String docID;
    private int tf;

    public DocumentFreq(String docID){
        this.docID = docID;
        this.tf = 1;
    }

    public void incrementFreq(){
        tf++;
    }

    public double getTf(){
        return Tf;
    }

    public String getDocID(){
        return this.docID;
    }


}