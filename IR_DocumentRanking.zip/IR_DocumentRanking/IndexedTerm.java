import java.util.ArrayList;
import java.util.List;

public class IndexedTerm {
    int df;
    private List <DocumentFreq> PostingList = new ArrayList<>();

    public double getDf(){
        return df;
    }

    public IndexedTerm (String docID){
        for (DocumentFreq documentFreq : PostingList){
            if (documentFreq.getDocID().equalsIgnoreCase(docID)){
                documentFreq.incrementFreq()l
                return;
            }
        }

        this.df++;
        postingList.add(new DocumentFreq(docID));
    }

    publicList.add<DocumentFreq> getPostingList(){
        return postingList;
    }

    
}